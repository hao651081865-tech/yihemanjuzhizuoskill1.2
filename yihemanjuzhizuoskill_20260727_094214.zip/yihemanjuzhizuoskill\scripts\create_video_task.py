"""Deprecated legacy video submitter.

The comic-drama-master workflow no longer submits text-only legacy video
tasks from this script. Use scripts/batch_video.py validate/generate instead;
that path uploads character, scene, and prop references and keeps retrying
until every scene video is complete.
"""

import sys


MESSAGE = """create_video_task.py is deprecated for comic-drama-master.

Use the all-reference workflow:
  python scripts/batch_video.py validate --prompts-file prompts.json --durations-file durations.json --reference-assets-file reference_assets_manifest.json
  python scripts/batch_video.py generate --prompts-file prompts.json --durations-file durations.json --reference-assets-file reference_assets_manifest.json --output-dir "<CODEX_ASSET_DIR>/<剧名>/视频/第一集" --max-retries 0 --submit-retry-interval 40
"""


if __name__ == "__main__":
    print(MESSAGE, file=sys.stderr)
    raise SystemExit(2)
