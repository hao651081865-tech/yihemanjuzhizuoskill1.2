import argparse
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    from .lk888_image_client import DEFAULT_POLL_INTERVAL, DEFAULT_TIMEOUT, Lk888ImageClient
except ImportError:
    from lk888_image_client import DEFAULT_POLL_INTERVAL, DEFAULT_TIMEOUT, Lk888ImageClient


DEFAULT_MAX_WORKERS = 3
CHARACTER_REFERENCE_SUFFIX = (
    "16:9 horizontal character design sheet, split layout, left one-third area shows a front "
    "close-up portrait with complete frontal face and clear facial features, right two-thirds "
    "area shows three separate full-body views of the same character arranged left to right: "
    "front view, side view, back view, equal height, full body head-to-toe visible, neutral "
    "standing pose, pure white seamless background, no shadow, no environment, no props, "
    "no handheld objects, no carried items, no bags, no handbag, no purse, no shoulder bag, "
    "no crossbody bag, no backpack, no phone, no keys, no document, no cup, no umbrella, "
    "no tool, no weapon, no pouch, no props blocking the outfit, original fictional non-celebrity face, avoid resemblance to real "
    "actors or public figures, distinct facial proportions, complete human anatomy, full "
    "limbs visible, no extra arms, no extra legs, no duplicated person, no scene background, "
    "no cinematic background, no poster composition"
)
SCENE_REFERENCE_SUFFIX = (
    "reusable environment reference asset, wide complete panoramic establishing composition, "
    "clearly visible main structure, foreground, midground, background and spatial boundaries, "
    "key anchor objects and available standing zones clearly visible with enough empty space "
    "for later character placement, no close crop, no missing anchors, no vague generic background, "
    "no storyboard frame, no specific camera action"
)
PROP_REFERENCE_SUFFIX = (
    "reusable prop reference asset, single standalone prop only, prop design sheet, split layout, "
    "left one-third area shows main front close-up view of this single prop, right two-thirds area "
    "shows three-view lineup of the same single prop arranged left to right: front view, side view, "
    "back view, equal height, pure white seamless background, subject centered and fully visible, "
    "no characters, no hands, no tabletop arrangement, no environment background, no other objects, "
    "no second prop, no grouped props, no accessory object"
)


def load_json_file(path):
    with open(path, "r", encoding="utf-8-sig") as file:
        return json.load(file)


def _simplify_prompt(prompt: str) -> str:
    replacements = {
        "blood": "spiritual energy",
        "bloody": "intense",
        "bleeding": "glowing with energy",
        "sword piercing": "sword energy clash",
        "killing": "defeating",
        "dead body": "fallen warrior",
        "corpse": "motionless figure",
        "explosion": "energy eruption",
        "war": "confrontation",
        "battle": "encounter",
    }
    simplified = prompt
    for old, new in replacements.items():
        simplified = simplified.replace(old, new)
    return simplified


def _is_character_asset(prompt: str, filename: str) -> bool:
    prompt_lower = (prompt or "").lower()
    filename_lower = (filename or "").lower()
    return (
        filename_lower.startswith("char_")
        or "/char_" in filename_lower
        or "\\char_" in filename_lower
        or "character reference asset" in prompt_lower
        or "character portrait" in prompt_lower
    )


def _is_scene_asset(prompt: str, filename: str) -> bool:
    prompt_lower = (prompt or "").lower()
    filename_lower = (filename or "").lower()
    return (
        filename_lower.startswith("scene_")
        or "/scenes/" in filename_lower
        or "\\scenes\\" in filename_lower
        or "reusable environment reference asset" in prompt_lower
    )


def _is_prop_asset(prompt: str, filename: str) -> bool:
    prompt_lower = (prompt or "").lower()
    filename_lower = (filename or "").lower()
    return (
        filename_lower.startswith("prop_")
        or "/props/" in filename_lower
        or "\\props\\" in filename_lower
        or "reusable prop reference asset" in prompt_lower
    )


def _enforce_character_reference_prompt(prompt: str, filename: str) -> str:
    if not _is_character_asset(prompt, filename):
        return prompt

    prompt_lower = prompt.lower()
    required_terms = (
        "16:9",
        "front close-up",
        "three-view",
        "front view",
        "side view",
        "back view",
        "pure white",
        "no shadow",
        "no environment",
        "no props",
        "no bags",
        "no handheld objects",
    )
    if all(term in prompt_lower for term in required_terms):
        return prompt

    return f"{prompt}, {CHARACTER_REFERENCE_SUFFIX}"


def _enforce_scene_reference_prompt(prompt: str, filename: str) -> str:
    if not _is_scene_asset(prompt, filename):
        return prompt

    prompt_lower = prompt.lower()
    required_terms = (
        "wide complete",
        "foreground",
        "midground",
        "background",
        "spatial boundaries",
        "standing zones",
    )
    if all(term in prompt_lower for term in required_terms):
        return prompt

    return f"{prompt}, {SCENE_REFERENCE_SUFFIX}"


def _enforce_prop_reference_prompt(prompt: str, filename: str) -> str:
    if not _is_prop_asset(prompt, filename):
        return prompt

    prompt_lower = prompt.lower()
    required_terms = (
        "prop design sheet",
        "front close-up",
        "three-view",
        "pure white",
        "no characters",
        "no hands",
    )
    if all(term in prompt_lower for term in required_terms):
        return prompt

    return f"{prompt}, {PROP_REFERENCE_SUFFIX}"


def _enforce_reference_prompt(prompt: str, filename: str) -> str:
    prompt = _enforce_character_reference_prompt(prompt, filename)
    prompt = _enforce_scene_reference_prompt(prompt, filename)
    prompt = _enforce_prop_reference_prompt(prompt, filename)
    return prompt


def _generate_single(prompt, output_dir, filename, index, max_retries):
    last_error = None
    client = Lk888ImageClient()
    poll_interval = int(os.getenv("LK888_POLL_INTERVAL", DEFAULT_POLL_INTERVAL))
    timeout = int(os.getenv("LK888_TIMEOUT", DEFAULT_TIMEOUT))

    for attempt in range(1, max_retries + 1):
        try:
            paths = client.generate_image(
                prompt=prompt,
                output_dir=output_dir,
                filename=filename,
                poll_interval=poll_interval,
                timeout=timeout,
            )
            print(f"[{index + 1}] generated: {filename}", flush=True)
            return {
                "index": index,
                "status": "success",
                "filepath": paths[0],
                "filename": filename,
                "error": None,
            }
        except Exception as exc:
            last_error = str(exc)
            print(f"[{index + 1}] attempt {attempt}/{max_retries} failed: {last_error}", flush=True)
            if attempt < max_retries:
                time.sleep(2**attempt)

    return {
        "index": index,
        "status": "failed",
        "filepath": os.path.join(output_dir, filename),
        "filename": filename,
        "error": last_error,
    }


def batch_image_generate(
    prompts,
    output_dir,
    prefix="scene_",
    ext=".jpg",
    max_workers=DEFAULT_MAX_WORKERS,
    max_retries=3,
    filenames=None,
):
    if not prompts:
        return {"status": "error", "message": "prompts list is empty", "results": []}

    os.makedirs(output_dir, exist_ok=True)
    if filenames and len(filenames) == len(prompts):
        names = filenames
    else:
        names = [f"{prefix}{i + 1:02d}{ext}" for i in range(len(prompts))]

    print(f"Generating {len(prompts)} images with GPT Image 2...", flush=True)
    start_time = time.time()
    results = []

    prompts = [_enforce_reference_prompt(prompt, name) for prompt, name in zip(prompts, names)]

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(_generate_single, prompt, output_dir, name, i, max_retries)
            for i, (prompt, name) in enumerate(zip(prompts, names))
        ]
        for future in as_completed(futures):
            results.append(future.result())

    results.sort(key=lambda item: item["index"])
    failed = [item for item in results if item["status"] == "failed"]

    if failed:
        print(f"Retrying {len(failed)} failed images with simplified prompts...", flush=True)
        retry_results = []
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [
                executor.submit(
                    _generate_single,
                    _simplify_prompt(prompts[item["index"]]),
                    output_dir,
                    item["filename"],
                    item["index"],
                    2,
                )
                for item in failed
            ]
            for future in as_completed(futures):
                retry_results.append(future.result())

        for retry_result in retry_results:
            if retry_result["status"] == "success":
                for i, result in enumerate(results):
                    if result["index"] == retry_result["index"]:
                        results[i] = retry_result
                        break

    succeeded = [item for item in results if item["status"] == "success"]
    failed = [item for item in results if item["status"] == "failed"]
    elapsed = time.time() - start_time

    return {
        "status": "success" if not failed else "partial" if succeeded else "failed",
        "total": len(prompts),
        "succeeded": len(succeeded),
        "failed": len(failed),
        "elapsed_seconds": round(elapsed, 1),
        "results": results,
        "saved_files": [item["filepath"] for item in succeeded],
        "failed_indices": [item["index"] for item in failed],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Batch generate images using lk888.ai GPT Image 2")
    parser.add_argument("--prompts-file", help="JSON file containing a string array of prompts")
    parser.add_argument("--prompts", nargs="+", help="Prompt list")
    parser.add_argument("--output-dir", required=True, help="Image output directory")
    parser.add_argument("--prefix", default="scene_", help="Filename prefix")
    parser.add_argument("--ext", default=".jpg", help="Filename extension")
    parser.add_argument("--max-workers", type=int, default=DEFAULT_MAX_WORKERS)
    parser.add_argument("--max-retries", type=int, default=3)
    parser.add_argument("--filenames-file", help="Optional JSON file containing filenames")
    args = parser.parse_args()

    if args.prompts_file:
        prompts = load_json_file(args.prompts_file)
    elif args.prompts:
        prompts = args.prompts
    else:
        raise SystemExit("Error: provide --prompts-file or --prompts")

    filenames = None
    if args.filenames_file:
        filenames = load_json_file(args.filenames_file)

    result = batch_image_generate(
        prompts=prompts,
        output_dir=args.output_dir,
        prefix=args.prefix,
        ext=args.ext,
        max_workers=args.max_workers,
        max_retries=args.max_retries,
        filenames=filenames,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))

    if result["status"] == "failed":
        raise SystemExit(1)
