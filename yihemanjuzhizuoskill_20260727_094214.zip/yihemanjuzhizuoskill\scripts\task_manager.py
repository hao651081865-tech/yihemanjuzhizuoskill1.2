"""
Task directory manager for the comic-drama production skill.

Rules:
- All drama files live under CODEX_ASSET_DIR/{剧名}, default D:/codex资产/{剧名}.
- Process docs/prompts, image assets, scene videos, and final videos share that drama folder.
- Do not create separate E: process/final folders or duplicate image/video asset folders.
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

logger = logging.getLogger(__name__)

_MAX_TASKS = 16


def _sanitize_name(name: str) -> str:
    sanitized = re.sub(r"[^\w\u4e00-\u9fff\-]", "_", name or "")[:30]
    return sanitized.strip("_") or "task"


def _resolve_asset_root() -> Path:
    env_val = os.environ.get("CODEX_ASSET_DIR", "").strip()
    return Path(env_val) if env_val else Path("D:/codex资产")


def _resolve_drama_name(task_name: str) -> str:
    explicit = os.environ.get("COMIC_DRAMA_NAME", "").strip()
    if explicit:
        return _sanitize_name(explicit)

    raw = (task_name or "").strip()
    for marker in ("_", "＿", " 第", "-第", "第1集", "第一集", "第01集"):
        idx = raw.find(marker)
        if idx > 0:
            candidate = raw[:idx].strip("_ -＿")
            if candidate:
                return _sanitize_name(candidate)
    return _sanitize_name(raw)


def _cleanup_old_tasks(outputs_dir: Path, max_tasks: int = _MAX_TASKS) -> List[str]:
    task_dirs = sorted(
        [d for d in outputs_dir.iterdir() if d.is_dir() and d.name.startswith("task_")],
        key=lambda d: d.stat().st_ctime,
    )
    deleted: List[str] = []
    while len(task_dirs) >= max_tasks:
        oldest = task_dirs.pop(0)
        shutil.rmtree(oldest, ignore_errors=True)
        deleted.append(oldest.name)
        logger.info("[task_manager] removed old task folder: %s", oldest)
    return deleted


def init_task(task_name: str) -> Dict:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    drama_name = _resolve_drama_name(task_name)
    task_id = f"task_{timestamp}"

    drama_asset_dir = _resolve_asset_root() / drama_name
    task_folder = drama_asset_dir
    character_dir = drama_asset_dir / "人物资产"
    scene_dir = drama_asset_dir / "场景资产"
    prop_dir = drama_asset_dir / "道具资产"
    video_dir = drama_asset_dir / "视频" / "第一集"
    final_dir = drama_asset_dir
    prompts_dir = task_folder / "prompts"

    for folder in [
        task_folder,
        prompts_dir,
        character_dir,
        scene_dir,
        prop_dir,
        video_dir,
        final_dir,
    ]:
        folder.mkdir(parents=True, exist_ok=True)

    # Backward-compatible keys intentionally point to the canonical user-facing
    # asset folders, not duplicate folders inside task_folder.
    return {
        "task_id": task_id,
        "task_folder": str(task_folder.absolute()),
        "prompts_dir": str(prompts_dir.absolute()),
        "assets_dir": str(drama_asset_dir.absolute()),
        "scenes_dir": str(scene_dir.absolute()),
        "props_dir": str(prop_dir.absolute()),
        "characters_dir": str(character_dir.absolute()),
        "videos_dir": str(video_dir.absolute()),
        "final_dir": str(final_dir.absolute()),
        "drama_name": drama_name,
        "drama_asset_dir": str(drama_asset_dir.absolute()),
        "visible_character_dir": str(character_dir.absolute()),
        "visible_scene_dir": str(scene_dir.absolute()),
        "visible_prop_dir": str(prop_dir.absolute()),
        "visible_video_dir": str((drama_asset_dir / "视频").absolute()),
        "outputs_dir": str(drama_asset_dir.absolute()),
        "deleted_tasks": [],
    }


def save_task_document(task_folder: str, doc_name: str, content: str) -> str:
    folder = Path(task_folder)
    folder.mkdir(parents=True, exist_ok=True)
    file_path = folder / doc_name
    file_path.write_text(content, encoding="utf-8")
    return str(file_path.absolute())


def list_tasks() -> List[Dict]:
    outputs_dir = _resolve_asset_root()
    outputs_dir.mkdir(parents=True, exist_ok=True)
    tasks: List[Dict] = []
    for folder in sorted(
        [x for x in outputs_dir.iterdir() if x.is_dir()],
        key=lambda x: x.stat().st_ctime,
        reverse=True,
    ):
        files = [str(f.relative_to(folder)) for f in folder.rglob("*") if f.is_file()]
        tasks.append(
            {
                "task_folder": str(folder.absolute()),
                "name": folder.name,
                "created_at": datetime.fromtimestamp(folder.stat().st_ctime).isoformat(),
                "file_count": len(files),
                "files": files[:20],
            }
        )
    return tasks


def main() -> int:
    if len(sys.argv) < 2:
        print("用法:")
        print('  python scripts/task_manager.py init "<task_name>"')
        print('  python scripts/task_manager.py save "<task_folder>" "<doc_name>" "<content>"')
        print("  python scripts/task_manager.py list")
        return 1

    cmd = sys.argv[1]
    if cmd == "init":
        if len(sys.argv) < 3:
            print("错误: 缺少 task_name 参数")
            return 1
        print(json.dumps(init_task(sys.argv[2]), ensure_ascii=False, indent=2))
        return 0

    if cmd == "save":
        if len(sys.argv) < 5:
            print("错误: 用法: python scripts/task_manager.py save <task_folder> <doc_name> <content>")
            return 1
        path = save_task_document(sys.argv[2], sys.argv[3], sys.argv[4])
        print(json.dumps({"saved": path}, ensure_ascii=False))
        return 0

    if cmd == "list":
        print(json.dumps(list_tasks(), ensure_ascii=False, indent=2))
        return 0

    print(f"未知命令: {cmd}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
