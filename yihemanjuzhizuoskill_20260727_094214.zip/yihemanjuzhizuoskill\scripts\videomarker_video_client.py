import json
import os
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Callable


DEFAULT_MODEL = "sd-2-motion-plus-720"
DEFAULT_SIZE = "720x1280"
DEFAULT_TIMEOUT = 1800
DEFAULT_POLL_INTERVAL = 8
DEFAULT_ASSET_DIR = r"D:\codex资产"
SUCCEEDED_STATUSES = {"completed", "succeeded", "success"}
FAILED_STATUSES = {"failed", "cancelled", "canceled"}
MODEL_ALLOWED_SECONDS = {
    "sd-2-full-720": [5, 10, 15],
    "sd-2-motion-720": [5, 10, 15],
    "sd-2-motion-plus-720": [5, 10, 15],
}


def get_env_value(name: str) -> str | None:
    if os.name == "nt":
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
                value, _ = winreg.QueryValueEx(key, name)
                if value:
                    return str(value)
        except OSError:
            pass
    value = os.getenv(name)
    if value:
        return value
    return None


def get_base_url() -> str:
    base_url = get_env_value("VIDEOMARKER_BASE_URL") or get_env_value("VIDEO_API_BASE_URL")
    if not base_url:
        raise RuntimeError("Missing Videomarker base URL. Set VIDEOMARKER_BASE_URL or VIDEO_API_BASE_URL.")
    return base_url.rstrip("/")


def get_auth_headers() -> dict:
    headers = {"User-Agent": "codex-comic-drama/1.0"}
    token = (
        get_env_value("VIDEOMARKER_API_KEY")
        or get_env_value("VIDEOMARKER_TOKEN")
        or get_env_value("VIDEO_API_KEY")
        or get_env_value("VIDEO_API_TOKEN")
    )
    if not token:
        raise RuntimeError("Missing Videomarker API key. Set VIDEOMARKER_API_KEY, VIDEOMARKER_TOKEN, VIDEO_API_KEY, or VIDEO_API_TOKEN.")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def default_request_json(method: str, url: str, payload: dict | None = None, headers: dict | None = None) -> dict:
    data = None
    request_headers = dict(headers or {})
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request_headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=request_headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            body = response.read().decode("utf-8", errors="replace")
            return json.loads(body) if body else {}
    except urllib.error.HTTPError as exc:
        body_text = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body_text}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Network error: {exc.reason}") from exc


def default_download_file(url: str, filepath: str, headers: dict | None = None) -> None:
    request = urllib.request.Request(url, headers=headers or {"User-Agent": "codex-comic-drama/1.0"})
    with urllib.request.urlopen(request, timeout=900) as response:
        Path(filepath).write_bytes(response.read())


def mirror_to_asset_dir(filepath: str, asset_subdir: str | None = None) -> str | None:
    # Videos are downloaded directly into the canonical output directory.
    # Do not mirror/copy them elsewhere; duplicate local files break the skill rules.
    return None


def _safe_ref_name(value: str, used: set[str]) -> str:
    base = Path(value).stem if value else "ref"
    name = "".join(char if char.isalnum() else "_" for char in base).strip("_") or "ref"
    original = name
    index = 2
    while name in used:
        name = f"{original}_{index}"
        index += 1
    used.add(name)
    return name[:40]


def normalize_reference_assets(scene_assets: dict) -> list[dict]:
    references = []
    used_names: set[str] = set()
    for category in ("characters", "subjects", "props", "scenes", "backgrounds"):
        for item in scene_assets.get(category, []) or []:
            if isinstance(item, str):
                source = item
                name = _safe_ref_name(source, used_names)
            elif isinstance(item, dict):
                source = item.get("path") or item.get("url") or item.get("image")
                if not source:
                    raise ValueError(f"Reference asset missing path/url/image: {item}")
                name = _safe_ref_name(item.get("name") or item.get("ref_name") or source, used_names)
            else:
                raise ValueError(f"Unsupported reference asset entry: {item}")
            references.append({"source": source, "name": name})
    if not references:
        raise ValueError("Each scene must include at least one reference asset.")
    return references


def prepare_prompt(prompt: str, references: list[dict]) -> str:
    prepared = prompt
    mapping_lines = []
    for index, item in enumerate(references, start=1):
        marker = f"@图片{index}"
        name = item["name"]
        prepared = prepared.replace(f"@{name}", marker)
        mapping_lines.append(f"{marker}={name}")
    return "素材映射：" + "；".join(mapping_lines) + "\n" + prepared


def normalize_seconds(duration: int, model: str) -> int:
    allowed = MODEL_ALLOWED_SECONDS.get(model, [10, 15])
    requested = int(duration)
    for value in allowed:
        if requested <= value:
            return value
    return allowed[-1]


def choose_model_for_references(references: list[dict]) -> str:
    forced_model = get_env_value("VIDEOMARKER_FORCE_MODEL") or get_env_value("VIDEO_MODEL")
    if forced_model:
        return forced_model
    return DEFAULT_MODEL


def _is_public_https_url(value: str) -> bool:
    return value.startswith("https://")


def _upload_local_to_tos(path: str) -> str:
    try:
        from tos_upload import upload_file_to_tos
    except Exception as exc:
        raise RuntimeError(
            "Videomarker /v1 API requires public HTTPS media_urls. "
            "Local files require TOS upload support; scripts/tos_upload.py is unavailable."
        ) from exc

    url = upload_file_to_tos(path)
    if not url or not _is_public_https_url(url):
        raise RuntimeError(
            "Videomarker /v1 API requires public HTTPS media_urls. "
            "Local file upload to TOS failed or did not return an HTTPS URL."
        )
    return url


def resolve_media_url(source: str) -> str:
    if _is_public_https_url(source):
        return source
    if source.startswith(("http://", "asset://")):
        raise ValueError(f"Videomarker /v1 media_urls must be public HTTPS URLs: {source}")
    path = Path(source)
    if not path.exists():
        raise FileNotFoundError(f"Reference asset not found: {source}")
    return _upload_local_to_tos(str(path))


def _task_id_from_response(response: dict) -> str:
    task = response.get("task") if isinstance(response.get("task"), dict) else response
    task_id = task.get("task_id") or task.get("id")
    if not task_id:
        raise RuntimeError(f"Videomarker response missing task id: {response}")
    return str(task_id)


def _task_list_from_usage(response: dict) -> list[dict]:
    if isinstance(response.get("tasks"), list):
        return response["tasks"]
    data = response.get("data")
    if isinstance(data, dict) and isinstance(data.get("tasks"), list):
        return data["tasks"]
    return []


def _video_url_from_task(task: dict) -> str | None:
    for key in ("video_url", "url", "download_url"):
        if task.get(key):
            return str(task[key])
    return None


class VideoMarkerVideoClient:
    def __init__(
        self,
        base_url: str | None = None,
        request_json: Callable | None = None,
        download_file: Callable | None = None,
        sleep: Callable[[float], None] | None = None,
    ):
        self.base_url = (base_url or get_base_url()).rstrip("/")
        self._headers = get_auth_headers()
        self._request_json = request_json
        self._download_file = download_file or default_download_file
        self._sleep = sleep or time.sleep

    def request_json(self, method: str, path: str, payload: dict | None = None) -> dict:
        url = f"{self.base_url}{path}"
        if self._request_json:
            return self._request_json(method, url, payload)
        return default_request_json(method, url, payload=payload, headers=self._headers)

    def get_balance(self) -> dict:
        return self.request_json("GET", "/v1/videos")

    def create_video_task(self, reference_assets: dict, prompt: str, duration: int) -> str:
        references = normalize_reference_assets(reference_assets)
        model = choose_model_for_references(references)
        body = {
            "model": model,
            "prompt": prepare_prompt(prompt, references),
            "seconds": normalize_seconds(int(duration), model),
            "size": get_env_value("VIDEOMARKER_SIZE") or get_env_value("VIDEO_SIZE") or DEFAULT_SIZE,
            "media_urls": [resolve_media_url(item["source"]) for item in references],
        }
        return _task_id_from_response(self.request_json("POST", "/v1/videos", body))

    def get_task(self, task_id: str) -> dict:
        return self.request_json("GET", f"/v1/videos/{urllib.parse.quote(str(task_id), safe='')}")

    def poll_video(
        self,
        task_id: str,
        interval: int = DEFAULT_POLL_INTERVAL,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> tuple[str, dict]:
        deadline = time.time() + timeout
        while time.time() < deadline:
            task = self.get_task(task_id)
            status = str(task.get("status", "")).lower()
            progress = task.get("progress")
            print(f"task_id={task_id} status={status} progress={progress}", flush=True)
            if status in SUCCEEDED_STATUSES:
                video_url = _video_url_from_task(task)
                if not video_url:
                    raise RuntimeError(f"Videomarker task completed but missing video_url: {task}")
                if video_url.startswith("/"):
                    video_url = f"{self.base_url}{video_url}"
                return video_url, task
            if status in FAILED_STATUSES:
                raise RuntimeError(f"Videomarker task failed: {task.get('error_message') or task}")
            self._sleep(interval)
        raise TimeoutError(f"Videomarker task {task_id} did not finish within {timeout} seconds")

    def generate_from_references(
        self,
        reference_assets: dict,
        prompt: str,
        duration: int,
        output_dir: str,
        filename: str,
        poll_interval: int = DEFAULT_POLL_INTERVAL,
        timeout: int = DEFAULT_TIMEOUT,
        asset_subdir: str | None = None,
    ) -> dict:
        if not prompt:
            raise ValueError("Prompt is empty.")
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        filepath = output_path / filename

        task_id = self.create_video_task(reference_assets, prompt, duration)
        result_url, status_resp = self.poll_video(str(task_id), interval=poll_interval, timeout=timeout)
        self._download_file(result_url, str(filepath), headers=self._headers)
        mirrored = mirror_to_asset_dir(str(filepath), asset_subdir=asset_subdir)
        return {
            "task_id": str(task_id),
            "result_url": result_url,
            "filepath": str(filepath),
            "mirrored": mirrored,
            "status": status_resp,
        }
