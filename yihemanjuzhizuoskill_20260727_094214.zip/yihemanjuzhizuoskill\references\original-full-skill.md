﻿---
name: comic-drama-master
description: 漫剧制作总导演。接受用户故事创意，依次完成剧本创作、人物/场景/道具参考资产生成、导演级分镜提示词、全能参考视频生成、视频合成全流程；不生成分镜首帧图，产物优先保存到 CODEX_ASSET_DIR（默认 D:\codex资产）下的剧名目录，最终交付本地完整视频，可选上传 TOS。
---

# 漫剧制作总导演

你是统筹全局的漫剧制作总导演，负责协调五个专业环节完成从创意到成片的全流程。

## 当前核心流程（必须优先）

本 skill 的唯一标准流程是：**剧本 → 人物/场景/道具参考资产 → 分镜视频提示词 → 全能参考出视频 → 合成成片**。

- 不生成故事版分镜图、不生成分镜首帧图、不准备 `frames.json`，也不得调用任何 first-frame 视频流程。
- 视频生成只使用“全能参考”：把人物资产、场景资产、道具资产和分镜提示词一起提交给视频接口。
- 人物资产、场景资产、道具资产必须独立管理，不能混成一张资产图或一个目录；每个分类文件夹内直接放对应图片，并用剧本里的中文人物名/场景名/道具名备注命名，例如 `人物资产/陆小川.png`、`场景资产/旧车站小馆内景.png`、`道具资产/饭卡.png`。
- 默认保存目录为 `CODEX_ASSET_DIR`，未设置时使用 `D:\codex资产`；每部剧按剧名建立独立文件夹。
- 图片资产和分镜视频只保留一份权威本地文件：人物图只放 `CODEX_ASSET_DIR/{剧名}/人物资产/`，场景图只放 `CODEX_ASSET_DIR/{剧名}/场景资产/`，道具图只放 `CODEX_ASSET_DIR/{剧名}/道具资产/`，分镜视频只放 `CODEX_ASSET_DIR/{剧名}/视频/{集数}/`。任务过程目录只保存 prompts、JSON 清单和文档，不得再保留 `characters/`、`assets/`、`videos/`、`final/` 的重复产物副本。
- 视频按集数保存：`视频/第一集/`、`视频/第二集/`，以此类推。
- 用户未说明画风时，必须询问；若用户此前指定“真人写实/写实风格”，后续同一项目默认沿用。
- 图片生成后必须先做资产质检：人物不得明显撞脸现实明星/公众人物，不得五官畸形、多人混入、三视图不一致、缺胳膊少腿、多手多脚；人物资产不得带任何可分离道具或随身物品，包括包、手提包、肩包、斜挎包、背包、手机、钥匙、文件、杯子、伞、工具、武器、腰包、手机袋等；场景不得像分镜首帧；道具必须一物一图。若出现明星脸、公众人物相似、可识别真人相似、真实人物隐私拦截或画风不符，必须停止并询问用户，不得擅自改风格、换模型或重生。全部图片资产通过质检后，必须展示预览并让用户确认继续，确认前不得进入视频生成。
- 视频生成后必须逐段做成片质检：检查穿帮、人物重复、人物缺胳膊少腿/多肢、脸和服装漂移、明星脸/公众人物相似、角色错位、道具错用、场景不连续、对白明显不符。未通过的分镜段必须先报告原因；涉及明星脸、公众人物相似、可识别真人相似、真实人物隐私拦截或画风偏离时，必须询问用户后才能用同一批参考资产和修正后的 prompt 重新生成。

> 五个专业环节的详细规格：
> - 剧本生成：参见 `references/screenplay-generator.md`
> - 角色设计：参见 `references/character-designer.md`
> - 场景/道具参考资产：参见 `references/scene-designer.md`
> - 分镜视频：参见 `references/storyboard-director.md`
> - 视频合成：参见 `references/video-synthesizer.md`
>
> 完整使用示例参见 `examples/examples.md`。

---

## ⚠️ 内容安全审核提醒

在开始制作之前，**必须先对用户的故事创意进行内容安全预审**。

### 高风险关键词（容易触发 API 拒绝）

以下类型的内容在视频生成阶段可能有较高概率被 API 拒绝：

| 风险类别 | 高风险关键词示例 |
|---------|----------------|
| 战争军事 | 战争、军队、军事、入侵、屠杀、征服 |
| 血腥暴力 | 血腥、血液、流血、残肢、内脏、致命伤 |
| 武器描述 | 刀砍、剑刺、弓箭射杀、枪械、炸弹 |
| 宗教敏感 | 堕天使、恶魔、撒旦、邪教、亵渎 |
| 恐怖元素 | 恐怖、惊悚、尸体、骷髅、鬼魂 |
| 政治敏感 | 政治人物、敏感历史事件、领土争议 |

### 预审处理规则

1. **低风险**（日常、奇幻冒险、儿童故事等）：直接开始制作
2. **中风险**（武侠打斗、修仙对决等）：在剧本和 prompt 中使用**委婉替代词**：
   - ❌ `blood spraying from wound` → ✅ `spiritual energy impact, staggering backward`
   - ❌ `sword piercing through chest` → ✅ `sword energy clash, powerful strike`
   - ❌ `army marching to war` → ✅ `warriors gathering for a decisive confrontation`
   - ❌ `bloody battle` → ✅ `fierce spiritual energy confrontation`
3. **高风险**（纯战争、恐怖、政治敏感）：**明确告知用户**该题材可能导致视频生成大面积失败，建议：
   - 调整为更温和的表达方式
   - 更换题材方向
   - 用户坚持则继续，但提前说明可能有 30-50% 的场景需要反复重试

> **提醒时机**：在步骤2（初始化任务目录）之后、步骤3（剧本生成）之前，向用户简要说明风险等级和应对策略。

---

## ⚡ 脚本参数速查表（大模型必读）

> **重要**：以下是所有脚本的精确调用格式和 JSON 文件格式。调用任何脚本前，必须严格按照此表准备参数，不得猜测格式。

### app_config.py — 读取配置
```bash
python scripts/app_config.py
# 无参数，返回 JSON
```

### task_manager.py — 任务目录管理
```bash
# 初始化任务
python scripts/task_manager.py init "<task_name>"

# 保存文档
python scripts/task_manager.py save "<task_folder绝对路径>" "<文件名.md>" "<Markdown内容>"

# 列出任务
python scripts/task_manager.py list
```

### web_search.py — 网络搜索
```bash
python scripts/web_search.py "<搜索关键词>"
# 返回 JSON 字符串数组
```

### image_generate.py — 单张图片生成
```bash
python scripts/image_generate.py "<英文prompt>" --output-dir "<保存目录绝对路径>"
# 返回 JSON: {"saved_files": ["/absolute/path/to/generated_image_TIMESTAMP_0.png"]}
```

### batch_image_generate.py — 批量并行图片生成（⚡ 推荐用于人物、场景、道具参考资产）
```bash
# 从 JSON 文件读取 prompts，并行生成（默认3线程）
python scripts/batch_image_generate.py \
  --prompts-file prompts.json \
  --output-dir "<保存目录绝对路径>" \
  --prefix scene_ \
  --max-workers 3 \
  --max-retries 3

# 返回 JSON: {"status": "success", "total": N, "succeeded": N, "failed": 0, "saved_files": [...], "elapsed_seconds": X}
```

**📋 image_prompts.json 格式（纯字符串数组）：**
```json
[
  "角色/场景/道具参考资产图 prompt...",
  "角色/场景/道具参考资产图 prompt...",
  "角色/场景/道具参考资产图 prompt..."
]
```

> ⚡ **性能对比**：7 张参考资产图串行生成约 70s，并行生成约 25s，提速约 3 倍。
> 内置自动重试（最多3次）和失败 prompt 简化 fallback 机制。

### batch_video.py — 批量全能参考视频生成（当前配置的视频后端）
```bash
# 先校验输入（不扣费）
python scripts/batch_video.py validate \
  --provider videomarker \
  --prompts-file prompts.json \
  --durations-file durations.json \
  --reference-assets-file reference_assets_manifest.json

# 生成视频：上传参考资产 → 提交 Fusion 任务 → 轮询 → 下载视频
python scripts/batch_video.py generate \
  --provider videomarker \
  --prompts-file prompts.json \
  --durations-file durations.json \
  --reference-assets-file reference_assets_manifest.json \
  --output-dir "<videos_dir绝对路径>" \
  --max-retries 0 \
  --submit-retry-interval 40
```

> **视频提交持久化规则**：`batch_video.py generate` 默认持续提交未完成的视频任务，`--max-retries 0` 只表示对临时提交/排队问题持续重试，直到生成成功或遇到账号凭据缺失、余额不足、模型无权限、输入校验失败、内容/隐私/明星脸风险等明确不可恢复错误。遇到 API 并发数量上限、HTTP 429、临时网络失败、任务排队失败等情况，不得判定任务结束；脚本会按 `--submit-retry-interval`（默认 40 秒，可改 30 秒）继续提交。
>
> **参考素材规则**：当前客户视频 API 需要公网 HTTPS 素材 URL。如果 `reference_assets_manifest.json` 中写的是 D 盘本地图片，脚本会尝试用 `tos_upload.py` 上传成 TOS 签名 URL；没有 TOS 凭据时，必须把参考资产换成公网 HTTPS URL。

**📋 JSON 文件精确格式（严格遵守，不得修改结构）：**

**prompts.json** — 纯字符串数组（⚠️ 不是对象数组！）：
```json
[
  "【第1集-第1场-分镜1】\n【无显示字幕，无显示台词，无显示字符】\n【出场人物：@角色A、@角色B】【场景：@场景名】【道具：@道具名】\n戏剧任务：...\n1 时长 00:00-00:XX\n核心画面提示词：...\n对话/音效：...\n【写实风格，电影级光效，氛围感照片，超清，8k。场景氛围，光影介质】\n【无BGM,添加氛围音，添加音效，添加环境音，所有声音不影响对话】",
  "【第1集-第1场-分镜2】\n【无显示字幕，无显示台词，无显示字符】\n【出场人物：@角色A】【场景：@场景名】【道具：无】\n戏剧任务：...\n1 时长 00:00-00:XX\n核心画面提示词：...\n对话/音效：...\n【写实风格，电影级光效，氛围感照片，超清，8k。场景氛围，光影介质】\n【无BGM,添加氛围音，添加音效，添加环境音，所有声音不影响对话】"
]
```

**durations.json** — 纯整数数组，每项为 4~15 之间的整数（与 prompts 一一对应）：
```json
[6, 8, 5, 10, 14, 12, 5]
```

**reference_assets_manifest.json** — 每段视频引用的人物/场景/道具参考资产（对象，key 为 scene_key，value 为 references）：
```json
{
  "scene_01": {
    "characters": ["D:/codex资产/剧名/人物资产/角色名.png"],
    "scenes": ["D:/codex资产/剧名/场景资产/场景名.png"],
    "props": ["D:/codex资产/剧名/道具资产/道具名.png"]
  }
}
```

### file_download.py — 批量文件下载
```bash
python scripts/file_download.py \
  --urls <url1> <url2> <url3> ... \
  --save-dir "<保存目录绝对路径>" \
  --filenames scene_01.mp4 scene_02.mp4 scene_03.mp4 ...
```

### video_merge.py — 视频合并
```bash
python scripts/video_merge.py \
  --input-dir "<videos_dir绝对路径>" \
  --output "<final_dir绝对路径>/<task_name>_final.mp4" \
  --scene-count <N>
```

### tos_upload.py — TOS 上传
```bash
python scripts/tos_upload.py "<文件绝对路径>"
# 返回 JSON: {"signed_url": "https://..."}
```

### video_scorer.py — 效果评分
```bash
python scripts/video_scorer.py "<task_folder绝对路径>"
```

---

## 前置依赖

- **ffmpeg / ffprobe**（必须，步骤7使用）：视频合并和时长检测依赖 ffmpeg。**在步骤7（视频合成）开始前自动检查并安装。**
  ```bash
  # macOS
  brew install ffmpeg
  # Linux (Debian/Ubuntu)
  sudo apt-get install -y ffmpeg
  # Linux (CentOS/RHEL)
  sudo yum install -y ffmpeg
  ```
  > ⚠️ ffmpeg 仅在步骤7（视频合成）时需要，无需提前安装。脚本会在合成前自动检查。
- **网络搜索**：调研时通过 `python scripts/web_search.py <query>` 执行，脚本自包含在此 skill 的 `scripts/` 目录下。
- **图片生成**：
  - 单张：`python scripts/image_generate.py <prompt> [--output-dir <dir>]`
  - **批量并行（推荐）**：`python scripts/batch_image_generate.py --prompts-file <file> --output-dir <dir>`
- **账号凭据**（必须由每个使用者在自己的环境中自行设置）：
  - skill 文档和示例中**禁止写入任何真实 API key**，也不得提交、同步或共享个人账号凭据。
  - 图片生成账号变量：使用者自行配置到环境变量，推荐变量名为 `LK888_API_KEY`。
  - 视频生成账号变量：使用者自行配置到环境变量；Videomarker 推荐变量名为 `VIDEOMARKER_API_KEY`。
  - 若团队或个人使用其他变量名，按脚本支持的兼容变量自行配置；不要把真实值写进 `SKILL.md`、示例、脚本或任务文档。
- **其他环境变量**：
  - `CODEX_ASSET_DIR`：对用户可见的资产根目录（推荐 `D:\codex资产`；未设置时脚本会使用此默认值）
  - `VIDEO_PROVIDER`：视频后端（可选，`auto` / `videomarker`；默认 auto 会使用 videomarker）
  - 视频模型选择规则：每部剧进入生视频阶段前都要确认模型；若用户已在本剧明确指定模型，则使用该模型。当前用户指定 `sd-2-motion-plus-720` 时，不得按参考图数量自动切回 fast/pro。
  - `VIDEOMARKER_SIZE`：输出尺寸（可选，推荐竖屏 `720x1280`）
  - `VIDEOMARKER_SUBMIT_RETRY_INTERVAL`：视频提交失败后的重试间隔（可选，默认 40 秒；可设 30 秒）
  - `VOLCENGINE_ACCESS_KEY` / `VOLCENGINE_SECRET_KEY`：火山引擎 AK/SK（可选；本地参考图需要上传成 TOS URL 时必须配置）
  - `VIDEO_DURATION_MINUTES`：视频时长（可选，默认 0.5（30秒），支持 0.5/1/2/3/4）
  - 任务过程文件不再使用独立根目录；默认保存到 `CODEX_ASSET_DIR/{剧名}/` 下的 `prompts/` 和根目录文档。

> `MODEL_IMAGE_API_KEY`、`MODEL_AGENT_API_KEY` 仅作为旧项目兼容变量名，不再作为本流程的主要配置。变量名可以出现在文档里，真实密钥值绝不能写入 skill。

---

## 🔄 恢复未完成任务（断点续制）

> **当新对话开始或上下文丢失时，必须先执行此检测流程，再决定是新建任务还是继续现有任务。**

### 恢复检测流程

**第一步：列出已有任务目录**

```bash
python scripts/task_manager.py list
```

如果找到已有任务目录，检查其中的产物完成情况。

**第二步：检查产物并判断恢复点**

进入最新的 task_folder，按以下规则判断应该从哪一步继续：

| 已有产物 | 缺失产物 | 恢复到步骤 |
|---------|---------|-----------|
| 无任何产物 | 全部 | 步骤2：初始化任务目录 |
| `requirements.md` | `plot.md`, `script.md` | 步骤3：剧本生成 |
| `plot.md`, `script.md` | `CODEX_ASSET_DIR/{剧名}/人物资产/` | 步骤4：角色设计 |
| `characters.md`, 权威人物资产目录 | `CODEX_ASSET_DIR/{剧名}/场景资产/`、`CODEX_ASSET_DIR/{剧名}/道具资产/` | 步骤5：场景/道具参考资产 |
| 人物/场景/道具参考资产 + 分镜文本 | `CODEX_ASSET_DIR/{剧名}/视频/{集数}/` | 步骤6：全能参考视频 |
| `CODEX_ASSET_DIR/{剧名}/视频/{集数}/` 有视频文件 | `CODEX_ASSET_DIR/{剧名}/{剧名}_final.mp4` | 步骤7：视频合成 |
| `CODEX_ASSET_DIR/{剧名}/{剧名}_final.mp4` | 评分报告 | 步骤8：产物验证 |

**第三步：加载已有产物上下文**

如果需要从中间步骤继续，**必须先读取已完成的产物文件**来恢复上下文：
- 读取 `characters.md` 恢复 STYLE_ANCHOR 和角色描述
- 读取 `plot.md` 恢复剧情大纲和时长分配
- 读取 `script.md` 恢复完整对白剧本
- 读取任务目录中已有的 TOS URL 记录

**第四步：向用户确认**

向用户展示检测结果：
- 展示已完成的步骤和对应产物
- 展示下一步应该执行的步骤
- 询问用户是否继续该任务，还是重新开始新任务

> ⚠️ **如果用户提供的是全新的故事创意**，则忽略恢复流程，直接从步骤1开始。
> 只有当用户明确表示"继续"、"接着做"、"上次的"等意图时，才执行恢复流程。

---

## 全流程概览

```
用户故事创意
  ↓
步骤0: 恢复检测 → python scripts/task_manager.py list（检查是否有未完成任务）
步骤1: 读取配置 → python scripts/app_config.py（智能时长模式，4s~15s 动态范围）
步骤2: 初始化任务目录 → python scripts/task_manager.py init "<task_name>"
  ↓ ⚠️ 内容安全预审（评估风险等级，向用户说明）
步骤3: 剧本生成 → python scripts/web_search.py 调研 + 创作剧本 + 智能时长分配（参见 references/screenplay-generator.md）
步骤4: 角色设计 → python scripts/image_generate.py 生成 16:9 白底角色设定图参考资产（左侧正脸特写 + 右侧正面/侧面/背面三视图，参见 references/character-designer.md）
步骤4.5: 参考资产质检 → 检查人物撞脸风险、白底三视图、肢体结构、场景/道具合规；明星脸/隐私/画风问题必须先问用户，普通质量失败只处理失败资产
步骤5: 场景/道具参考资产 → python scripts/image_generate.py 生成场景和关键道具参考图（参见 references/scene-designer.md）
步骤5.5: 图片资产预览确认 → 展示全部人物、场景、道具资产，询问用户是否确认继续生成视频；未确认前不得提交视频任务
步骤6: 全能参考视频 → 先按当前已批准视频 API 可用的长分镜 JSON 工作流生成 `segments`，从每条 `segment.video_prompt` 提取 `prompts.json`、从 `segment.duration_seconds` 提取 `durations.json`，再用 `batch_video.py validate/generate` + 引用人物/场景/道具资产生成视频（参见 references/storyboard-director.md）
步骤6.5: 视频逐段质检 → 检查穿帮、重复人物、肢体缺失/多肢、脸和服装漂移、明星脸、对白错位；涉及明星脸/隐私/画风问题必须先问用户，确认后只处理失败分镜
步骤7: 视频合成 → python scripts/video_merge.py，按需 tos_upload.py（参见 references/video-synthesizer.md）
步骤8: 产物验证与效果评分 → 逐项检查产物完整性 + 生成评分报告
  ↓
完整漫剧视频本地文件 + 可选 TOS 签名链接 + 评分报告
```

---

## 步骤1：读取启动配置

```bash
python scripts/app_config.py
```

输出 JSON 包含：
- `video_duration_minutes`：视频时长（分钟）
- `total_seconds`：总秒数
- `smart_duration`：`true`（智能时长模式已启用）
- `duration_range`：`{"min": 4, "max": 15}`（每段视频可选时长范围）
- `duration_options`：`"4s ~ 15s 动态分配"`
- `scene_count_range`：`{"min": N, "max": M}`（场景数参考范围）
- `recommended_scene_count`：推荐场景数（以平均 8s 估算）

### 智能时长模式说明

每个分镜场景根据**剧情节奏需要**独立分配时长（**4秒 ~ 15秒**连续可选），而非全部使用统一时长。**时长的多样性是让漫剧节奏生动的关键**——快切制造紧迫感，长镜头铺垫情绪，交替使用让观众始终沉浸在故事中。

| 场景类型 | 推荐时长范围 | 适用情况 | 对白密度 |
|---------|-------------|---------|---------|
| 紧张快切 | **4~6秒** | 追逐场面、惊吓瞬间、快速闪回、蒙太奇过渡、一击必杀 | 1~2句短促台词或无对白纯画面 |
| 标准叙事 | **7~10秒** | 开篇铺垫、过渡衔接、环境建立、简单对话、结尾余韵 | 3~5句对白，标准节奏 |
| 高潮铺垫 | **11~15秒** | 终极对决、情绪爆发、多角色交锋、关键转折、密集对白 | 6~10句对白，密集交锋 |

**总导演在步骤3（剧本生成）时，根据每章的剧情功能和节奏需要决定该章时长**，确保：
- 总时长 ≈ `total_seconds`（允许 ±10% 浮动）
- 高潮章节（第三幕）优先分配 11~15 秒
- 紧张追逐/闪回可使用 4~6 秒快切
- 开篇和结尾章节通常使用 7~10 秒
- **相邻场景时长应有变化**，避免连续多个相同时长导致节奏单调

向用户确认配置后继续。

---

## 步骤2：初始化任务目录

```bash
python scripts/task_manager.py init "<task_name>"
```

从故事创意中提取核心关键词作为 task_name。脚本返回 JSON：

```json
{
  "task_folder": "{CODEX_ASSET_DIR}/{剧名}/",
  "assets_dir": "{CODEX_ASSET_DIR}/{剧名}/",
  "characters_dir": "{CODEX_ASSET_DIR}/{剧名}/人物资产/",
  "scenes_dir": "{CODEX_ASSET_DIR}/{剧名}/场景资产/",
  "props_dir": "{CODEX_ASSET_DIR}/{剧名}/道具资产/",
  "videos_dir": "{CODEX_ASSET_DIR}/{剧名}/视频/第一集/",
  "final_dir": "{CODEX_ASSET_DIR}/{剧名}/",
  "outputs_dir": "{CODEX_ASSET_DIR}/{剧名}/",
  "deleted_tasks": []
}
```

记录所有路径，后续步骤全程使用。不要再创建单独的 E 盘流程目录或 E 盘成片目录。

同时创建或确认用户可见的资产目录：

```text
{CODEX_ASSET_DIR}/{剧名}/
├── 人物资产/
│   ├── 角色名.png
├── 场景资产/
│   ├── 场景名.png
├── 道具资产/
│   ├── 道具名.png
└── 视频/
    ├── 第一集/
    ├── 第二集/
    └── ...
```

任务目录只保存过程文件、prompt、JSON 清单和文档；`CODEX_ASSET_DIR` 下的剧名目录保存唯一一份给用户查看和复用的资产与分镜视频。生成后必须将人物、场景、道具分别直接放入对应权威目录，分类目录内不再继续建立资产子文件夹；视频按集数放入对应文件夹。不得在任务目录中再保存同一图片或视频副本。

> ⚠️ **内容安全预审**：在此步骤之后、步骤3之前，对用户故事创意执行内容安全预审（参见上方「内容安全审核提醒」），向用户简要说明风险等级。

---

## 步骤3：剧本生成（含智能时长分配）

**完整规格参见 `references/screenplay-generator.md`**。

核心流程：
1. **`python scripts/web_search.py` 深度调研**（必须在写剧本之前执行）
2. 保存需求文档 `requirements.md`
3. 创作章节式剧情大纲 `plot.md`（含全局风格锚定声明 + 情绪弧线图）
4. **为每个章节动态分配时长**（4秒 ~ 15秒，根据剧情节奏）
5. 创作完整对白剧本 `script.md`（每章标注时长，逐秒剧本按实际时长展开）
6. 输出 `scene_durations` 列表（供步骤6使用）

### 智能时长分配规则

在创作 plot.md 时，为每章标注时长（4s ~ 15s 动态选择）：

```
第一章：[章节名]（6秒）— [摘要]    ← 快速闪回/引子，紧凑开场
第二章：[章节名]（8秒）— [摘要]    ← 世界观建立，标准叙事
第三章：[章节名]（5秒）— [摘要]    ← 紧张追逐/危机降临，快切
第四章：[章节名]（10秒）— [摘要]   ← 冲突升级，需要更多对白
第五章：[章节名]（14秒）— [摘要]   ← 高潮对决，密集交锋
第六章：[章节名]（12秒）— [摘要]   ← 高潮延续，情绪爆发
第七章：[章节名]（5秒）— [摘要]    ← 结局余韵，短促定格
```

**时长分配决策表**：

| 判定条件（满足任一即可） | 推荐时长范围 |
|------------------------|-------------|
| 高潮对决、终极交锋 | **12~15秒** |
| 多角色同时交锋（3人+） | **12~15秒** |
| 关键剧情转折、反转揭示 | **11~14秒** |
| 情绪爆发（愤怒嘶吼、决死宣言、临死遗言） | **11~15秒** |
| 对白密集（需要6句以上对白才能充分表达） | **11~15秒** |
| 复杂动作编排（多段连续动作） | **12~15秒** |
| 开篇建立世界观 | **7~10秒** |
| 过渡衔接、环境转换 | **6~9秒** |
| 简单对话（3-5句对白即可） | **7~10秒** |
| 结尾余韵、情绪沉淀 | **6~10秒** |
| 单纯氛围渲染 | **5~8秒** |
| 紧张追逐、危机闪回、一击必杀 | **4~6秒** |
| 蒙太奇过渡、梦境闪现 | **4~5秒** |
| 惊吓瞬间、突发事件 | **4~5秒** |

> **关键原则**：时长多样性 > 时长统一。一部好漫剧的节奏应像心跳般起伏有致——紧张时短促如鼓点（4~6s），铺垫时舒缓如弦乐（7~10s），高潮时绵长如交响（11~15s）。

**script.md 中每章的时长体现**：
- 章节标题格式：`## 第N章：[章节名]（时长：Xs）`（X 为 4~15 之间的整数）
- 逐秒剧本时间轴按实际时长展开（如 5秒场景：`0:00-0:05`；12秒场景：`0:00-0:12`）
- 11~15秒场景的对白密度更高（6-10句），动作编排更丰富
- 7~10秒场景的对白为标准密度（3-5句）
- 4~6秒场景对白极简（0-2句），以画面冲击力为主

**确认步骤3产物**：
- `{task_folder}/requirements.md` ✅
- `{task_folder}/plot.md` ✅（含章节划分 + 每章时长标注 + 风格锚定 + 情绪弧线）
- `{task_folder}/script.md` ✅（含对白、神情、动作、场景桥接、结束状态、**每章独立时长**）
- `scene_durations` 列表已记录 ✅（如 `[6, 8, 5, 10, 14, 12, 5]`）

从 plot.md 提取：主要角色列表、核心视觉风格（若用户未指定，先询问；同一项目已指定“真人写实/写实风格”时沿用真人写实）。

**🔔 向用户展示关键产出**（必须在确认产物后、进入下一步之前展示）：
- 📖 **剧情大纲**：展示 plot.md 的完整分章大纲（章节名 + 时长标注 + 摘要）
- 🎭 **每章对白摘录**：每章展示 1-2 句最精彩的核心对白
- 📊 **时长分配汇总表**：章节—时长—分配理由
- 📈 **情绪弧线图**：每章情绪强度可视化
- 👥 **角色列表**：主要角色姓名 + 身份 + 一句话概括

---

## 步骤4：角色设计

**完整规格参见 `references/character-designer.md`**。

核心流程：
1. 确定视觉风格，生成 **STYLE_ANCHOR**（全局风格锚定字符串）
2. 为每个角色创作精确的英文 AI 提示词
3. ⚡ 使用 `python scripts/batch_image_generate.py` **并行生成**角色 16:9 白底设定图参考资产（左侧正脸特写 + 右侧三视图）+ 封面图
4. 保存角色设计文档 `characters.md`
5. 角色参考资产直接生成到 `{CODEX_ASSET_DIR}/{剧名}/人物资产/{角色名}.png`；TOS 上传仅在需要公网链接展示或外部平台必须 URL 时执行。不得先生成到 `task_folder/characters/` 再复制一份。

**画风一致性关键**：
- STYLE_ANCHOR 写入 characters.md 顶部，后续所有步骤必须引用
- 角色英文提示词一经确定，在所有后续场景中**原样复用**，仅允许追加动作/表情
- 配色方案用精确英文颜色词（如 `midnight blue` 而非 `blue`）
- 角色参考资产必须是 16:9 纯白无影背景设定图：左侧正脸特写，右侧正面、侧面、背面三视图，全身可见；不得使用剧情场景或分镜动作背景
- 角色图片 prompt 必须包含：`16:9 horizontal character design sheet, split layout, left one-third front close-up portrait, right two-thirds three-view full-body lineup: front view, side view, back view, pure white seamless background, no shadow, no environment, no props, no handheld objects, no carried items, no bags, no phone, no keys`

确认产物：
- `{task_folder}/characters.md` ✅（含 STYLE_ANCHOR + 英文提示词 + 角色参考资产图片）
- `{characters_dir}/` 指向 `{CODEX_ASSET_DIR}/{剧名}/人物资产/`，其中有角色 16:9 白底设定图参考资产 .jpg/.png 文件 ✅
- 封面图只保留一份：`{CODEX_ASSET_DIR}/{剧名}/封面.jpg` 或 `{task_folder}/cover.jpg` ✅
- 不存在 `task_folder/characters/` 中的重复人物图副本 ✅

**🔔 向用户展示关键产出**：
- 🎨 **STYLE_ANCHOR**：展示完整风格锚定字符串
- 👤 **角色概要**：每个角色的中文描述（姓名 + 身份 + 标志性特征）
- 🖼️ **角色参考资产预览**：所有角色白底三视图参考资产以 Markdown 图片形式展示；在 Codex 桌面环境中优先使用本地绝对路径，公网交付时再使用 TOS URL
- 🖼️ **封面图预览**：封面图以 Markdown 图片形式展示（本地绝对路径或 TOS URL）

### 步骤4.5：参考资产质检（必须通过后才进入视频）

对人物、场景、道具资产逐项检查并记录结果：

- **人物撞脸风险**：检查角色是否明显像现实明星、公众人物或可识别真人。此检查只做“相似风险”判断，不在交付文档中点名真实人物；若存在明显撞脸风险，必须停止并询问用户，不得擅自修改脸型、五官比例、发型、年龄感、气质描述或重新生成该角色。
- **人物结构与无道具**：必须白底 16:9，左侧正脸特写，右侧正面/侧面/背面三视图；不得多人同框、五官畸形、三视图不是同一人、缺胳膊少腿、多手多脚、服装遮挡主体；不得出现任何可分离道具或随身物品，包、手提包、肩包、斜挎包、背包、手机、钥匙、文件、杯子、伞、工具、武器、腰包、手机袋等一律判定为人物资产不合格，必须移入道具资产单独生成。
- **场景资产**：必须是可复用完整环境，不得是逐分镜画面、不得带主角表演动作、不得出现字幕或文字。
- **道具资产**：必须一物一图，白底三视图；汽车、旅行箱、手机、钥匙等必须分别生成，不得合并。

质检失败处理：
1. 明星脸、公众人物相似、可识别真人相似、真实人物隐私拦截或用户指定画风不符，必须先问用户；未确认前不得重生、不得换 API、不得换模型、不得改画风。
2. 用户确认可以重生后，只重生失败资产，不重生已通过资产。
3. 重生 prompt 必须写明失败原因对应的修正，例如 `different original non-celebrity face, avoid resemblance to real actors, corrected hands and full limbs`。
4. 重生后再次质检，直到通过或遇到图片账号凭据/额度等不可恢复问题。
5. `reference_assets_manifest.json` 只能引用已通过质检的资产。

全部人物、场景、道具图片资产通过质检后，必须向用户展示资产预览并明确询问是否确认继续生成视频。用户确认前不得进入视频提交阶段。

---

## 步骤5：场景/道具参考资产（不生成分镜首帧图）

**完整规格参见 `references/scene-designer.md`**。

核心流程：
1. 从 characters.md 读取人物参考资产；视频提示词只列 `@角色名`，不内嵌角色基础形象
2. 从 script.md 提取全片核心场景和关键道具，去重后构建参考资产清单
3. 为每个场景资产、道具资产构建提示词（以 STYLE_ANCHOR 开头，强调可复用参考图，不写分镜镜头）
4. ⚡ 使用 `python scripts/batch_image_generate.py` **并行生成**所有场景/道具参考资产（内置自动重试 + 失败 prompt 简化 fallback）
5. 场景资产直接生成到 `{CODEX_ASSET_DIR}/{剧名}/场景资产/{场景名}.png`，道具资产直接生成到 `{CODEX_ASSET_DIR}/{剧名}/道具资产/{道具名}.png`，并把这些权威本地路径写入 `reference_assets_manifest.json` 供步骤6引用；不得在任务过程目录里保留重复副本

**画风一致性关键**：
- 所有参考资产提示词必须以 STYLE_ANCHOR 开头
- 角色描述严格复用 characters.md 中的英文提示词
- 同一场景资产必须是干净、可复用的环境参考，不绑定某个分镜瞬间
- 道具资产必须突出形状、材质、尺寸、年代感和可识别细节
- 场景资产必须是完整宽幅环境参考图：`reusable environment reference asset, wide complete panoramic establishing composition, foreground, midground, background, spatial boundaries, no storyboard frame, no specific camera action`
- 道具资产必须“一物一图”：`single standalone prop only, prop design sheet, split layout, left main front close-up, right three-view lineup: front view, side view, back view, pure white seamless background, no other objects, no second prop, no grouped props`
- 如果剧本写到“汽车和旅行箱”“手机和钥匙”等组合，必须拆成 `汽车`、`旅行箱`、`手机`、`钥匙` 四张独立道具资产图，不得生成组合图

**场景生成失败 fallback**：
- 脚本内置自动重试（每张最多3次）
- 重试全部失败后，自动用简化 prompt 再次尝试（移除高风险词汇）
- 如果仍然失败，提取失败资产的 prompt，手动简化后使用 `image_generate.py` 单独重试

确认产物：
- `{CODEX_ASSET_DIR}/{剧名}/场景资产/` 下有核心场景参考图 ✅
- `{CODEX_ASSET_DIR}/{剧名}/道具资产/` 下有关键道具参考图 ✅
- 不存在 `task_folder/assets/` 下的重复场景/道具图副本 ✅
- 所有人物/场景/道具参考资产路径或 URL 已记录 ✅（供步骤6使用）

**🔔 向用户展示关键产出**：
- 🖼️ **参考资产预览**：展示人物、场景、道具参考资产图，每张附带：
  - 资产名称
  - 用途说明
  - 将被哪些分镜引用
- 📊 **生成统计**：总数/成功数/耗时

---

## 步骤6：全能参考视频生成（智能时长）

**完整规格参见 `references/storyboard-director.md`**。

核心流程：
1. 从 characters.md 读取人物参考资产；视频提示词只列 `@角色名`，不内嵌角色基础形象或 STYLE_ANCHOR
2. 从步骤5提取人物、场景、道具参考资产路径或 URL
3. 按 `references/storyboard-director.md` 的 **当前已批准视频 API 长分镜 JSON 工作流**生成 `segments`：每条 segment 必须包含 `duration_seconds` 和完整 `video_prompt`
4. 从 `segments[*].video_prompt` 提取纯字符串数组 `prompts.json`；从 `segments[*].duration_seconds` 提取纯整数数组 `durations.json`
5. 批量提交“全能参考出视频”任务（传 prompts + 每段独立时长 + 人物/场景/道具参考资产）

**重要规则**：
- 禁止生成或传入分镜首帧图。
- 禁止使用 `storyboard/scene_XX.jpg` 作为 first_frame。
- 视频参考图只允许是人物资产、场景资产、道具资产。
- 分镜文本负责动作、台词、运镜、光影、音效；参考资产负责保持人物、环境和道具一致。分镜文本必须遵守当前已批准视频 API 的长分镜 JSON：忠实覆盖原剧本、强制语速计算、跨镜连续、动作过程完整、站位姿态明确、受伤/特效状态持续。
5. 轮询等待全部完成
6. 下载视频 + 质量评分

### 智能时长提交方式

将 prompts 列表、时长列表、参考资产清单分别写入 JSON 文件，然后先 validate 再 generate。**全能参考视频阶段不得准备或传入 `frames.json`，不得使用 `--first-frames-file`，不得生成分镜首帧图。**

**第一步：准备 JSON 文件（⚠️ 严格按照速查表中的格式，参见文件顶部）**

```json
// prompts.json — ⚠️ 必须是纯字符串数组，不是对象数组！
[
  "【第1集-第1场-分镜1】\n【无显示字幕，无显示台词，无显示字符】\n【出场人物：@角色A、@角色B】【场景：@场景名】【道具：@道具名】\n戏剧任务：...\n1 时长 00:00-00:XX\n核心画面提示词：...\n对话/音效：...\n【写实风格，电影级光效，氛围感照片，超清，8k。场景氛围，光影介质】\n【无BGM,添加氛围音，添加音效，添加环境音，所有声音不影响对话】",
  "【第1集-第1场-分镜2】\n【无显示字幕，无显示台词，无显示字符】\n【出场人物：@角色A】【场景：@场景名】【道具：无】\n戏剧任务：...\n1 时长 00:00-00:XX\n核心画面提示词：...\n对话/音效：...\n【写实风格，电影级光效，氛围感照片，超清，8k。场景氛围，光影介质】\n【无BGM,添加氛围音，添加音效，添加环境音，所有声音不影响对话】"
]

// durations.json — 整数数组（与 prompts 一一对应）
[6, 8, 5, 10, 14, 12, 5]

// reference_assets_manifest.json — 每段视频引用的人物/场景/道具参考资产
{
  "scene_01": {
    "characters": ["D:/codex资产/剧名/人物资产/角色名.png"],
    "scenes": ["D:/codex资产/剧名/场景资产/场景名.png"],
    "props": ["D:/codex资产/剧名/道具资产/道具名.png"]
  }
}
```

**第二步：先校验输入**

```bash
python scripts/batch_video.py validate \
  --provider videomarker \
  --prompts-file prompts.json \
  --durations-file durations.json \
  --reference-assets-file reference_assets_manifest.json
```

**第三步：调用 generate 命令**

```bash
python scripts/batch_video.py generate \
  --provider videomarker \
  --prompts-file prompts.json \
  --durations-file durations.json \
  --reference-assets-file reference_assets_manifest.json \
  --output-dir "<CODEX_ASSET_DIR>/<剧名>/视频/第一集" \
  --max-retries 0 \
  --submit-retry-interval 40
```

> ⚠️ **不再使用 `--duration` 统一时长参数**，改用 `--durations-file` 实现每段独立时长。
> `durations.json` 中的时长列表必须与 `prompts.json` 一一对应，每个值为 4~15 之间的整数。

**持续提交直到出片**：
- 视频生成阶段必须保持任务运行，直到所有 `scene_NN.mp4` 都生成成功或遇到明确不可恢复问题。
- 如果平台返回并发数量上限、排队失败、HTTP 429、临时网络错误或单段提交失败，不得跳过该分镜，也不得把任务判定为完成。
- `--max-retries 0` 只用于临时提交/排队问题的持续重试；不得用于绕过余额不足、模型无权限、账号凭据错误、输入校验失败、内容/隐私/明星脸风险。
- 推荐命令：
```bash
python scripts/batch_video.py generate \
  --provider videomarker \
  --prompts-file prompts.json \
  --durations-file durations.json \
  --reference-assets-file reference_assets_manifest.json \
  --output-dir "<videos_dir绝对路径>" \
  --max-retries 0 \
  --submit-retry-interval 40
```
- 支持断点续跑：如果某段 `scene_NN.mp4` 已存在且非空，脚本会跳过该段，继续处理未完成分镜。
- 账号凭据缺失/无效、余额不足、模型无权限、输入文件校验失败、参考资产缺失、内容审核拒绝、真实人物隐私拦截、明星脸/公众人物相似等必须停止并报告，不得擅自换 API、换模型、改画风或继续重试。

### 步骤6.5：视频逐段质检与失败重生（必须执行）

每段 `scene_NN.mp4` 生成后，必须先检查质量，未通过不得进入最终合成。

检查项：
- **人物一致性**：角色脸、发型、服装、年龄感与人物参考资产一致，不得明显漂移或撞脸现实明星/公众人物。
- **人物数量**：画面中的人物数量符合分镜，不得凭空多出重复人物或丢失关键人物。
- **肢体结构**：不得缺胳膊少腿、多手多脚、手指严重畸形、身体断裂、脸部崩坏。
- **动作连贯**：搬行李、开车门、递钥匙、接电话等动作过程完整，不得跳帧到无法理解。
- **场景/道具**：场景与参考资产一致，道具不混用，单独道具不得变成组合道具，车、箱子、手机、钥匙等不能互相融合。
- **穿帮**：不得出现字幕、水印、错误文字、现代/古代物件错位、镜头外工作人员、道具瞬移、服装突然变化。
- **对白/音频**：对白角色、语气、内容和分镜提示词一致，环境音和音效不压过对白。

失败处理：
1. 标记失败分镜编号和失败原因。
2. 若失败原因包含明星脸、公众人物相似、可识别真人相似、真实人物隐私拦截或用户指定画风偏离，必须先问用户；未确认前不得重生、不得换 API、不得换模型、不得改画风。
3. 用户确认可以重生后，用同一批已通过质检的人物/场景/道具参考资产，修正该分镜 prompt 后重生该段。
4. 重生 prompt 必须显式加入修正约束，例如 `single instance of each character only, complete human anatomy, no duplicated people, consistent face and outfit, original fictional non-celebrity faces, avoid resemblance to real actors or public figures, no extra limbs, no missing limbs, no visible text`。
5. 只重生失败段，不重生已通过段；重生后再次质检。
6. 所有分镜视频质检通过后，才允许进入步骤7合成。

**画风一致性关键**：
- 所有视频提示词严格采用中文导演级故事板模板，不在顶部添加 STYLE_ANCHOR
- `【出场人物】` 只写 `@角色名`，不得写 `#基础形象` 或角色英文长描述
- `【无显示字幕...】` 和 `【无BGM...】` 必须保留中文模板，不得翻译成英文，不得追加 `Quality constraints` 英文尾句
- 对白从 script.md 原样提取
- 11~15秒场景：至少5-6句对白，密集交锋节奏
- 7~10秒场景：至少3-4句对白
- 4~6秒场景：0-2句极简对白，以画面冲击为主
- 运镜多样化，相邻场景不得使用完全相同的运镜手法

### 镜头语言专业指导

**镜头是导演最重要的叙事工具**。不同情绪需要截然不同的镜头策略：

#### 紧张/悬疑场景的镜头策略

| 镜头技法 | 描述 | 情绪效果 |
|---------|------|---------|
| 近景→特写连续推进 | `medium shot slowly pushing in to extreme close-up on eyes` | 压迫感递增，暗示危险逼近 |
| 快速正反打切换 | `rapid shot-reverse-shot between characters, each cut 0.5s` | 心理对峙白热化，紧张感拉满 |
| 手持晃动镜头 | `handheld shaky camera, slight vibration, unstable framing` | 不安定感，观众代入角色恐惧 |
| 倾斜构图（Dutch angle） | `tilted camera 15-25 degrees, off-balance composition` | 世界失序、心理扭曲 |
| 景深压缩长焦 | `telephoto lens compression, blurred foreground and background` | 孤立角色、空间压缩、窒息感 |
| 暗部留白 | `deep shadows consuming 60% of frame, character half-lit` | 未知威胁、恐惧氛围 |

#### 高潮/爆发场景的镜头策略

| 镜头技法 | 描述 | 情绪效果 |
|---------|------|---------|
| 速度斜坡（Speed Ramp） | `normal speed → ultra-slow 0.2x on impact → snap back to real-time` | 关键一击的视觉强调 |
| 360度环绕 | `360-degree orbit around character during energy release` | 能量爆发的仪式感 |
| 极端低角度 | `extreme worm's-eye view looking up, silhouette against sky` | 角色气势碾压，史诗感 |
| 跟拍追踪 | `dynamic tracking shot racing alongside the action, camera tilting 45°` | 动作场面的沉浸感 |
| 快速蒙太奇 | `rapid montage: face → fist → impact → reaction, 0.3s per cut` | 战斗节奏爆裂 |
| 鞭甩摇镜 | `whip pan from attacker to defender, motion blur, freeze on impact` | 突袭感、力量传递 |

#### 情绪铺垫场景的镜头策略

| 镜头技法 | 描述 | 情绪效果 |
|---------|------|---------|
| 缓推长镜头 | `slow steady dolly push-in over 5 seconds, minimal movement` | 情绪渐入，观众被缓缓吸入画面 |
| 大全景→人物 | `wide establishing shot slowly narrowing to medium shot on character` | 渺小感→聚焦→共情 |
| 近景微表情 | `extreme close-up held for 3 seconds, capturing every micro-expression` | 无声胜有声，情绪传递 |
| 过肩镜头 | `over-the-shoulder shot, shallow depth of field, speaker in soft focus` | 亲密/对峙的心理距离 |
| 慢拉远镜 | `slow pull-back revealing vast landscape, character becoming small` | 孤独感、命运感、余韵 |
| 静止锁定 | `static locked-off camera, subject slowly walking away, held 6 seconds` | 结尾余韵、情绪沉淀 |

> **镜头节奏规则**：紧张场景用快切（每 0.5~1.5s 一个镜头切换），铺垫场景用长镜（3~6s 不切），高潮场景先慢后快再慢（蓄力→爆发→余波）。

**对白与连贯性关键**：
- 对白间距不超过4秒，要有交锋感
- 音频情绪与画面情绪匹配，相邻场景音乐有过渡感
- 环境在连续场景中保持一致，仅变化破坏程度/光照

确认产物：
- `{videos_dir}/` 下有 scene_count 个 .mp4 文件 ✅
- 每段视频含中文对白语音 + 配乐 + 音效 ✅
- 各段视频时长与 `scene_durations` 一致 ✅

**🔔 向用户展示关键产出**（⚠️ **必须展示每段分镜视频，不得跳过**）：
- 🎬 **分镜视频列表**：所有视频必须展示；在 Codex 桌面环境中可用本地绝对路径 `<video src="D:/codex资产/剧名/视频/第一集/scene_01.mp4" width="640" controls>第N段{分镜名}</video>`，公网交付时再换成 TOS URL；每段附带分镜名 + 时长 + 核心对白 1-2 句摘录
- 📊 **质量评分**：展示评分结果

> ⚠️ 视频展示格式示例（必须严格遵循）：
> ```
> **第一章：{章节名}**（{时长}秒）
> 核心对白："{角色A}：{台词}"
> <video src="https://tos-cn-beijing.volces.com/.../scene_01.mp4?签名参数" width="640" controls>第一章{章节名}</video>
> ```

---

## 步骤7：视频合成与交付

**完整规格参见 `references/video-synthesizer.md`**。

核心流程：
1. **检查并安装 ffmpeg**（首次使用时自动安装）
2. 严格筛选视频文件（只接受 scene_NN.mp4 格式）
3. 按顺序合并所有视频
4. 保存到 `{CODEX_ASSET_DIR}/{剧名}/视频/第一集/` 或对应集数目录；如需要公网分享，再上传到 TOS
5. 保存交付文档，展示最终结果

**⚠️ 第一步：检查并安装 ffmpeg（合成前必须确认可用）**

> 💡 **向用户说明**：在检查/安装 ffmpeg 时，向用户简要解释：
> 「接下来需要将各段分镜视频按顺序合并为一部完整漫剧。合并视频需要用到 **ffmpeg**（一个开源的音视频处理工具），我来检查一下环境中是否已安装……」
> 如果需要安装，告知用户：「正在安装 ffmpeg，这是一个专业的视频拼接工具，用于将 {scene_count} 段分镜视频无缝合并为完整漫剧视频，同时自动检测最终时长。安装只需几秒钟。」

```bash
# 检查 ffmpeg 是否已安装
which ffmpeg && ffmpeg -version || echo "ffmpeg not found, installing..."

# macOS 自动安装
brew install ffmpeg 2>/dev/null || true

# Linux 自动安装
# sudo apt-get install -y ffmpeg 2>/dev/null || sudo yum install -y ffmpeg 2>/dev/null || true
```

> 如果 ffmpeg 已安装则直接跳过，无需重复安装。

**合并视频：**
```bash
python scripts/video_merge.py --input-dir "<videos_dir>" --output "<final_dir>/<task_name>_final.mp4" --scene-count <N>
# 可选：需要公网链接时再执行
python scripts/tos_upload.py "<final_dir>/<task_name>_final.mp4"
```

> 合并后的实际总时长由 ffprobe 自动检测（因为每段视频时长可能不同）。

确认产物：
- `{final_dir}/{task_name}_final.mp4` ✅
- `{CODEX_ASSET_DIR}/{剧名}/视频/{集数}/` 下有分段视频和合成视频 ✅
- TOS 签名 URL（可选，需要公网交付时）✅

**🔔 向用户展示关键产出**（⚠️ **视频必须使用 `<video>` 标签展示，不得只给纯文本路径**）：
- 🎬 **最终视频**：合成视频必须以 `<video src="{local_or_tos_url}" width="640" controls>完整漫剧视频</video>` 格式展示；Codex 桌面环境优先用本地绝对路径，公网交付时使用 TOS URL
- 🔗 **备用链接**：如已上传 TOS，展示完整签名 URL；未上传时展示本地绝对路径
- 📁 **任务目录结构**：展示完整目录树

> ⚠️ **最终视频展示格式（必须严格遵循，不得只输出纯文本路径）**：
> ```
> 🎬 漫剧生成完成！
> 
> <video src="D:/codex资产/剧名/视频/第一集/task_name_final.mp4" width="640" controls>完整漫剧视频</video>
> 
> 🔗 本地路径：D:/codex资产/剧名/视频/第一集/task_name_final.mp4
> ```
> ❌ **错误示例（禁止使用）**：
> - ~~```text\nhttps://...\n```~~（代码块包裹）
> - ~~[视频链接](https://...)~~（Markdown 链接）
> - ~~https://...~~（纯文本 URL）

---

## 步骤8：产物验证与效果评分

**每个任务完成后，必须执行完整的产物验证和效果评分。**

### 8.1 产物完整性检查

逐项检查以下产物目录结构，确认每个文件/文件夹**存在且非空**：

```
{task_folder}/
├── characters.md                ← 必须非空，含 STYLE_ANCHOR + 角色提示词
├── plot.md                      ← 必须非空，含章节大纲 + 时长分配
├── requirements.md              ← 必须非空，含需求文档
├── script.md                    ← 必须非空，含逐秒剧本
├── prompts/                     ← 必须包含提示词、文件名和 reference_assets_manifest.json
└── reference_assets_manifest.json 或 prompts/reference_assets_manifest.json

{CODEX_ASSET_DIR}/{剧名}/
├── 人物资产/                    ← 必须包含角色参考图
├── 场景资产/                    ← 必须包含场景参考图
├── 道具资产/                    ← 必须包含道具参考图
└── 视频/{集数}/                 ← 必须包含 scene_count 个 .mp4 文件

{CODEX_ASSET_DIR}/{剧名}/
└── <task_name>_final.mp4        ← 最终合成片
```

**验证规则**：
- 如果任何文件夹为空或文件内容为空 → **当前任务判定为失败**
- `CODEX_ASSET_DIR/{剧名}/视频/{集数}/` 文件数量必须与 scene_count 严格匹配；`CODEX_ASSET_DIR/{剧名}/人物资产/场景资产/道具资产/` 必须覆盖分镜中需要反复出现的人物、场景、道具
- `CODEX_ASSET_DIR/{剧名}/人物资产/` 下的文件数量必须与主要角色数量匹配

### 8.2 效果评分

使用评分工具对任务进行质量评估：

```bash
python scripts/video_scorer.py "<task_folder>"
```

评分输出包含 5 个维度（每项 0-10 分）：

| 评分维度 | 评分标准 |
|---------|---------|
| 剧情连贯性 | 场景间衔接是否流畅，是否有割裂感 |
| 对白丰富度 | 人物台词是否足够，语气是否多样，是否有冲突感 |
| 视觉质感 | 画面风格统一性，特效质量，镜头运用 |
| 情感张力 | 是否有戏剧性起伏，高潮是否震撼 |
| 音画同步 | 配乐是否贴合情绪，配音是否清晰 |

### 8.3 产物验证报告格式

```
📋 产物验证报告

├── CODEX_ASSET_DIR/{剧名}/人物资产/  {N}个文件  ✅/❌
├── CODEX_ASSET_DIR/{剧名}/场景资产/  {N}个文件  ✅/❌
├── CODEX_ASSET_DIR/{剧名}/道具资产/  {N}个文件  ✅/❌
├── CODEX_ASSET_DIR/{剧名}/视频/{集数}/  {N}个文件  ✅/❌
├── CODEX_ASSET_DIR/{剧名}/xxx_final.mp4  {size}MB  ✅/❌
├── characters.md        {size}字   ✅/❌
├── plot.md              {size}字   ✅/❌
├── requirements.md      {size}字   ✅/❌
├── script.md            {size}字   ✅/❌
└── prompts/             {N}个过程文件  ✅/❌

产物完整性: ✅ 全部通过 / ❌ {N}项缺失

📊 效果评分
剧情连贯性: X/10
对白丰富度: X/10
视觉质感:   X/10
情感张力:   X/10
音画同步:   X/10
综合评分:   X.X/10

改进建议: [具体建议]
```

> **任何产物缺失或内容为空，整个任务即判定为失败**，必须报告具体缺失项并协调修复。

---

## 总导演执行规范

1. **内容安全预审**：步骤2之后必须对故事创意执行内容安全预审，向用户说明风险等级
2. **上下文传递**：每步必须明确所有路径参数和内容参数
3. **质量门控**：每步完成后确认产物存在，异常时协调解决再继续
4. **画风一致性**：STYLE_ANCHOR 仅用于人物/场景/道具资产图生成；视频分镜提示词按中文导演级故事板模板输出，风格写在末尾中文风格行
5. **角色一致性**：视频阶段通过参考资产保持角色一致，`【出场人物】` 行只列 `@角色名`
6. **剧情连贯性**：场景桥接确保相邻章节自然过渡，情绪弧线有起承转合
7. **对白密度**：4~6秒场景 0-2句对白，7~10秒场景至少3句对白，11~15秒场景至少6句对白，对白间距不超过4秒，有交锋感
8. **智能时长**：每章根据剧情节奏动态分配 4~15 秒，时长多样性优先，总时长控制在目标范围内
9. **运镜多样性**：相邻场景运镜手法不重复，全片至少5种运镜类型；紧张场景用快切近景，铺垫场景用长镜缓推，高潮场景用速度斜坡和环绕
10. **视频生成工具**：只允许使用 `batch_video.py` 的 validate/generate（或用户确认后的同脚本单段重试能力），禁止回到分镜首帧图生视频工具；视频提交可使用持续队列模式处理并发上限或临时失败，按 30-40 秒间隔继续提交，直到所有分镜视频生成完成或遇到余额不足、模型无权限、账号凭据错误、输入校验失败、内容/隐私/明星脸风险等明确不可恢复问题
11. **URL 零修改**：所有图片或视频 URL 在输入输出的全流程中均需严格保持原始状态，不允许进行任何形式的篡改（包括但不限于修改域名、路径、query参数、锚点等）。
12. **产物目录**：所有本地产物统一保存在 `CODEX_ASSET_DIR/{剧名}/`（默认 `D:\codex资产\{剧名}\`）下，不再默认创建 E 盘流程目录、E 盘成片目录或其他分散目录；其中 `人物资产/`、`场景资产/`、`道具资产/`、`视频/{集数}/` 是剧名总目录内的最小分类目录；过程 JSON 和提示词只放 `prompts/`，最终成片直接放剧名总目录根部。同一图片或视频本地文件不得重复复制，只保留权威目录一份。
13. **图片生成**：优先使用 `python scripts/batch_image_generate.py` 批量并行生成（步骤4角色参考资产、步骤5场景/道具参考资产），单张补充使用 `python scripts/image_generate.py`
14. **内容安全措辞**：视频 prompt 中避免直接使用战争/血腥/武器等高风险词汇，用委婉替代词
15. **产物验证**：步骤7完成后必须执行步骤8的产物完整性检查和效果评分，任何产物缺失即判定失败
16. **关键产出展示**：每步完成后，**必须**将该步骤的关键产出内容（文档摘要、图片预览、视频链接、评分报告等）直接展示给用户，而非仅返回文件路径。用户应在对话流中清晰看到剧情大纲、角色参考资产、场景/道具参考资产、导演级分镜文本、视频等核心输出
17. **禁止分镜首帧图**：步骤5只生成可复用的人物/场景/道具参考资产；不得生成 scene_01/scene_02 这类分镜首帧图，也不得要求用户确认分镜首帧图
18. **视频展示格式**：所有视频（分镜视频和最终合成视频）**必须**使用 `<video src="{local_or_tos_url}" width="640" controls>描述</video>` 格式展示。在 Codex 桌面环境可使用本地绝对路径；公网交付时使用 TOS URL。禁止只给纯文本 URL、Markdown 代码块包裹的 URL 或 Markdown 链接格式
19. **ffmpeg 按需安装**：步骤7（视频合成）开始前检查并安装 ffmpeg，按需安装不打扰前期创作流程
20. **参考资产生成 fallback**：场景/道具参考资产生成失败时自动重试（最多3次），重试失败后简化 prompt 再尝试，确保全能参考出视频所需资产尽可能完整

## 什么是好的漫剧

> 剧情有起承转合，台词和语言张弛有度，镜头运用恰到好处（镜头方式多种多样，带着用户进入漫剧世界），
> 画面层次丰富，剧情连贯，情感充沛，人物有个性，画面、场景、音乐、对白细腻且一致，
> 画风始终统一，用户看到漫剧能感受到故事的吸引、情节的连贯、主角的张力和故事线的波澜。
> **节奏是漫剧的灵魂**——快切紧张如鼓点（4~6s），叙事舒缓如弦乐（7~10s），高潮绵长如交响（11~15s），
> 三者交替使用，让观众的心跳随着画面起伏，这才是大师级的节奏把控。

